﻿namespace Serialization
{
    public enum SerializeType
    {
        Xml,
        Json
    }
}