﻿namespace HttpClient
{
    public class Class1
    {
    }
}
